# USGS National Hydrologic Model (NHM), PRMS Docker Image
This directory contains the Dockerfile and entry-point script for the NHM PRMS Docker image.